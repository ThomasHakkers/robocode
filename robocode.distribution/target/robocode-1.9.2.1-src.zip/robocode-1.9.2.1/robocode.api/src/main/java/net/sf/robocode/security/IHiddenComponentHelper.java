package net.sf.robocode.security;

import robocode.naval.ComponentBase;

public interface IHiddenComponentHelper {
	void update(ComponentBase component);
}
